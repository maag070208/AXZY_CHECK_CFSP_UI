// components/ITBadge.tsx
import clsx from "clsx";
import { ITBadgetProps } from "./badget.props";
import {
  badgeSizes,
} from "@/types/badget.types";
import { theme } from "@/theme/theme";
import ITText from "@/components/atoms/text/text";

/**
 * Small status tag or label with theme-based colors and filled/outlined variants.
 *
 * @example
 * <ITBadget label="Active" color="success" variant="filled" />
 *
 * @example
 * <ITBadget color="danger" variant="outlined" size="sm">
 *   <span className="flex items-center gap-1">3 new</span>
 * </ITBadget>
 */
export default function ITBadget({
  children,
  label,
  color = "primary",
  size = "md",
  variant = "filled",
  className,
}: ITBadgetProps) {
  // Access theme configuration
  const themeBadge = (theme as any).badge || {};
  const config = themeBadge[color] || themeBadge.primary || {};

  const getStyle = () => {
    const style: React.CSSProperties = {
      fontWeight: config.fontWeight,
      borderRadius: config.borderRadius, // '9999px' in theme
      borderWidth: '1px', // Default border width for consistency
      borderStyle: 'solid',
      borderColor: 'transparent', // Default transparent
      transition: 'all 0.2s',
    };

    if (variant === "filled") {
      style.backgroundColor = config.backgroundColor;
      style.color = config.color;
      style.borderColor = config.borderColor || 'transparent'; // Some filled badges might have subtle borders
    } else if (variant === "outlined") {
      style.backgroundColor = "transparent";
      // Use the dark text color for both text and border to ensure high contrast
      style.color = config.color; 
      style.borderColor = config.color;
    }

    return style;
  };

  return (
    <span
      className={clsx(
        "inline-flex items-center justify-center",
        // Apply size classes (padding/font-size)
        badgeSizes[size],
        className
      )}
      style={getStyle()}
    >
      {children || <ITText as="span" className={clsx("font-semibold")}>{label}</ITText>}
    </span>
  );
}
